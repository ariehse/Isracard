

export class Bookmark {

  RepositoryID: string;

  OwnerImageUrl: string;

  RepositoryName: string;

  RepositoryShortName: string;

  CreatedDate: Date; 

  constructor() {}
}
