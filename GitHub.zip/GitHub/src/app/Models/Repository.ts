
export enum BookmarkStatus { Active , NotActive , Failed } 

export class Repository {
  ID: string;
  Avatar: string;
  Name: string;
  ShortName: string; 
  BookmarkStatus: BookmarkStatus

  constructor(avatar: string= "" , repositoryName: string="") {

    this.Avatar = avatar;
    this.Name = repositoryName;
    this.ShortName = this.Name.substring(0, 7);
    this.BookmarkStatus = BookmarkStatus.NotActive;
  }
}
