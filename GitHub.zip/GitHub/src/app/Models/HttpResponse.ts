

export class HttpResponse {

   Success : boolean ; 
   ErrorMessage : string 

  constructor( success :  boolean , error : string) {

   this.Success = success ; 
   this.ErrorMessage = error;
  }
}
