import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { appRoutes } from './routes';

/*
 *  Define the Module for rooting that allow navigation in the application .
 *  All Route has been defined in the appRoute Object .
 *
 *  
 */
@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
