import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';

import { BookmarkService } from './Bookmarks/Services/bookmark-service'
import { RepositoryService } from './Repositories/Services/repository-service'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RepositorySearchComponent } from './Repositories/Components/repository-search/repository-search.component';
import { BookmarkListComponent } from './Bookmarks/Components/bookmark-list/bookmark-list.component';
import { GaleryItemComponent } from './Shared/galery-item/galery-item.component';
import { GaleryComponent } from './Shared/galery/galery.component';
import { FilterRepositoryComponent } from './Repositories/Components/filter-repository/filter-repository.component';


@NgModule({
  declarations: [
    AppComponent,
    RepositorySearchComponent,
    BookmarkListComponent,
    GaleryItemComponent,
    GaleryComponent,
    FilterRepositoryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [BookmarkService, RepositoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
