import { Component, OnInit } from '@angular/core';
import { BookmarkService } from '../../Services/bookmark-service';
import { Bookmark } from '../../../Models/Bookmark';
import { HttpErrorResponse } from '@angular/common/http';



/*
 *  The Component Represent a Container that display into Image Item Galery all the bookmark saving in the server 
 *  The Container use the Galery component with Attribute GaleryType = Bookmark .  
 */
@Component({
  selector: 'bookmarks',
  templateUrl: './bookmark-list.component.html',
  styleUrls: ['./bookmark-list.component.css']
})
export class BookmarkListComponent implements OnInit {

   

  constructor() { }

  ngOnInit() {

  }
  
}
