import { Injectable } from '@angular/core';
import { Bookmark } from '../../Models/Bookmark';
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators'
import { HttpResponse } from '../../Models/HttpResponse';
import { HttpHeaders } from '@angular/common/http';




/*
 *  Define an Injectable service that will communicate with Bookmark Server that hold all bookmarks in the systems .
 *  The Service containing the following operations: 
 *         1. Create  :   post  a bookmark on the server 
 *         2. GetBookMarks :  retrieve all bookmarks saved on the server 
 */
@Injectable()
export class BookmarkService {


  private _hostURL: string;

  private _bookmarks: Array<Bookmark>;   // the result for all bookmarks for operation GetBookmarks 

  private  options = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private _bookmarkServer: HttpClient)
  {
    this._hostURL = "http://localhost:16559/Bookmark/";
    this._bookmarks = new Array<Bookmark>();

  }

  Create(bookmark: Bookmark): Observable<HttpResponse>  {

    let bookmarkRequest: string = JSON.stringify(bookmark);
    

    return this._bookmarkServer.post(this._hostURL + "Create", bookmarkRequest, this.options).pipe(map(response => {
      return new HttpResponse(response["Success"], response["ErrorMessage"]);
    }));

   
  }

  GetBookMarks(): Observable<Bookmark [] > {

    return this._bookmarkServer.get(this._hostURL + "GetBookmarks").pipe(
      map((res:Object []) => {
        return res.map(item => {

          let bookmark = new Bookmark();
          bookmark.RepositoryID = item["RepositoryID"];
          bookmark.OwnerImageUrl = item["OwnerImageUrl"];
          bookmark.RepositoryName = item["RepositoryName"];
          bookmark.RepositoryShortName = bookmark.RepositoryName.substring(0, 17);

          return bookmark;

        });
      })
    );
  }

}
