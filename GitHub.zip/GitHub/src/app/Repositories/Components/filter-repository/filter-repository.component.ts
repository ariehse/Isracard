import { Component, OnInit } from '@angular/core';
import { Repository } from '../../../Models/Repository';
import { RepositoryService } from '../../Services/repository-service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';


/*
 * Define the Component that will able to execute repository filtering with the RepositoryService 
 */
@Component({
  selector: 'filter-repository',
  templateUrl: './filter-repository.component.html',
  styleUrls: ['./filter-repository.component.css']
})
export class FilterRepositoryComponent implements OnInit {

  Repositories: Array<Repository>;    // hold the result of filtering 

  Query: string;                      // Query send to  the service 

  State: string = "Initial";          // define state for display message alerts of different issues occured in the application 

  SearchForm: FormGroup;                    
  private searchRepository: FormControl; 

  constructor(private repositoryService: RepositoryService) { }

  ngOnInit() {
    this.searchRepository = new FormControl("", Validators.required);

    this.SearchForm = new FormGroup({
      searchRepository: this.searchRepository

    });
  }



/*
 * define function that verify if the textbox for repository name has validation issues 
 */
  validateRepositoryName() {
    return this.searchRepository.valid || this.searchRepository.untouched;
  }

/*
 * define function that will execute when we do  a search and call the GetRepositories of RepositoryService - The Operation is valid only
 * if we don't any validation error .
 * the operation will update the  State variable in different value :
 *    1. before any search , the state is in mode Initial
 *    2. after a search ,  if we succeed to execute a query the state will be in mode Query  othrwise it will be in mode of the error
 *    
 */
  GetRepositories(formValues) {

    if (this.SearchForm.valid) {

      this.Query = formValues.searchRepository;
      this.repositoryService.GetRepositories(this.Query).subscribe((repositories: Repository[]) => {

        this.Repositories = repositories;
        this.State = 'Query';
      }, (error: HttpErrorResponse) => {

        console.log(error.message);
        this.State = 'Error';

      }); 

    }
    else
      this.State = 'Initial';

   
  }

}
