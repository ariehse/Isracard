import { Component, OnInit } from '@angular/core';
import { BookmarkService } from '../../../Bookmarks/Services/bookmark-service';
import { RepositoryService } from '../../Services/repository-service';
import { Repository, BookmarkStatus } from '../../../Models/Repository';
import { Bookmark } from '../../../Models/Bookmark';
import { HttpResponse } from '../../../Models/HttpResponse';
import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';




/*
 *  The Component Represent a Container for Filtering on GITHub Repository and display into Image Item Galery that will allow us to bookmark repositories.
 *  The Component Contains two child Components :
 *    1. FilterRepositoryComponent :  allow to execute queries and retieve a list of repository through Repository Service
 *    2. GaleryComponent :  component that display the repository and allow Bookmark operations
 *         2.1 if the Bookmark on specific repository has been succeeded on the server , the star button will be in yellow color and be disabled
 *         2.2 if the repository is not bookmarked , we will see a star button without any color background and active for click 
 *         2.3 if the repository has been failed when we bookmarked on the server , the star button will be in red color and allow to be clickable 
 */
@Component({
  selector: 'app-repository-search',
  templateUrl: './repository-search.component.html',
  styleUrls: ['./repository-search.component.css']
})
export class RepositorySearchComponent implements OnInit {

  
   


  constructor() {

  }

  ngOnInit() {

   
  }


  
}
