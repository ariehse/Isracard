

/*
 *  define a status for Bookmark operation .
 *    1. Active :  The Application will highlights the Repository has been boomarked
 *    2. NotActive :  The Application will show the repository without highlihting
 *    3. Failed :     Bookmark has been failed in the server , status that will tell to the user we have a problem to bookmark in the past 
 */
export enum BookmarkStatus { Active , NotActive , Failed } 

export class Repository {

  Avatar: string;
  Name: string;
  BookmarkStatus: BookmarkStatus

  constructor(avatar: string, repositoryName: string) {

    this.Avatar = avatar;
    this.Name = repositoryName; 
  }
}
