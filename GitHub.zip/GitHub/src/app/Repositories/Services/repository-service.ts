import { Injectable } from '@angular/core';
import { Repository } from '../../Models/Repository';
import { HttpClientModule, HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators'





/*
 *  Define an Injectable service that will communicate with External Service : https://api.github.com/search/repositories?q=YOUR_SEARCH_KEYWORD
 *  The Service containing the following operations: 
 *         1. GetRepositories  that will retrieve all repositories base on query string pass to q parameter in the web api GITHub service
 *            if will return an Observable of a collection of Repository 
 */
@Injectable()
export class RepositoryService {

 

  private HostUrl: string;


  constructor(private gitClient : HttpClient  ) {

   
    this.HostUrl = "https://api.github.com/search/repositories?q=";
  }


  GetRepositories(query: string): Observable<Repository[]> {     

    return this.gitClient.get(this.HostUrl + query).pipe(
      map(res => {
        return res["items"].map(item => {

          let repository: Repository = new Repository();
          repository.ID = item["id"];
          repository.Avatar = item["owner"]["avatar_url"];
          repository.Name = item["name"];
          repository.ShortName = repository.Name.substring(0,17);

          return repository; 


        });
      })
    );



  }


}
