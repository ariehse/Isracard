import { Routes } from '@angular/router';
import { RepositorySearchComponent } from './Repositories/Components/repository-search/repository-search.component';
import { BookmarkListComponent } from './Bookmarks/Components/bookmark-list/bookmark-list.component';

/*
 *  Define a Configuration Routing Object , that representing mapping between URL and Components in the AppModule 
 *
 *  
 */
export const appRoutes: Routes = [
  { path: '', redirectTo: '/Repositories', pathMatch: 'full' },
  { path: 'Repositories', component: RepositorySearchComponent },
  { path: 'Bookmarks', component: BookmarkListComponent }
]
