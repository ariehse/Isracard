import { Component, OnDestroy } from '@angular/core';
import { Bookmark } from './Models/Bookmark';
import { BookmarkService } from './Bookmarks/Services/bookmark-service'
import { HttpResponse } from './Models/HttpResponse';
import { Observable} from 'rxjs/Observable';
import { RepositoryService } from './Repositories/Services/repository-service';
import { Repository, BookmarkStatus } from './Models/Repository';

/*
 *  The Main Component of the Angular Client that will display  a Menu for navigation for two principal operation : 
 *         1. Bookmark repository coming from GITHub web service .
 *         2. Display all bookmarks existing in the server.
 *
 *  The Application have  the following File Structure :
 *         1. Bookmarks :  containing component and services for communicate with the Bookmark server .
 *         2. Models    :  hold all the models use by the application like Repository , Bookmark and on ...
 *         3. Repositories :  hold component and services for communicate with GITHub service
 *         4. Shared  :       Component use by Repositories and Bookmarks 
 */

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  //Bookmarks: Array<Bookmark>;
  //Response: HttpResponse;

  //Repositories: Array<Array<Repository>>;

  //State: string = "Initial";
  

  //Query: string;

  


  //constructor(private bookmarkService: BookmarkService,
  //  private repositoryService: RepositoryService)
  //{
    
  //}



  //GetRepositories() {

    


  //  this.Repositories = []; 

  //  this.repositoryService.GetRepositories(this.Query).subscribe((repositories: Repository[]) => {


  //    let count: number = 0;
  //    let rowID: number = 0;

  //    repositories.forEach(item => {


  //      if (count > 6) {
  //        rowID++;
  //        count = 0;
  //      }

  //      if (count == 0) {
  //        let items: Array<Repository> = [];
  //        this.Repositories.push(items);
  //        this.Repositories[rowID].push(item);
  //        count++;

  //      }
  //      else if (count < 7)
  //        this.Repositories[rowID].push(item);
  //      count++;
  //    });

  //    if (this.Repositories.length == 0)
  //      this.State = 'Query'
  //    else
  //      this.State = "None";

  //  }, (error: any) => {

  //    this.State = 'Error'; 
  //  });

    
  //}




  //CreateBookmark(repository: Repository) {

  //  let bookmark: Bookmark = new Bookmark();

  //  bookmark.RepositoryID = repository.ID; 
  //  bookmark.OwnerImageUrl = repository.Avatar; 
  //  bookmark.RepositoryName = repository.Name; 
  //  bookmark.CreatedDate = new Date();

  //  this.bookmarkService.Create(bookmark).subscribe((response: HttpResponse) => {
  //    this.Response = response;
  //    repository.BookmarkStatus = BookmarkStatus.Active;
  //  }
  //    , (error: string) => {
  //      console.log(error);
  //      repository.BookmarkStatus = BookmarkStatus.Failed;
  //    });

  //}

  //DisplayBookmarks() {

  //  this.bookmarkService.GetBookMarks().subscribe((response: Bookmark[]) => {
  //    this.Bookmarks = response
  //  });
    

  //}

 


}
