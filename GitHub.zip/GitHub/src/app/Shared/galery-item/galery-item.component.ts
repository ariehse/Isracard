import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Repository } from '../../Models/Repository';
import { Bookmark } from '../../Models/Bookmark';



/*
 *  The Component represent  an item that need to be display in GaleryComponent . the component represent Bookmark or Repository  depending the binding attribute
 *    1. RepositoryGaleryItem  : hold the repository to display 
 *    2. BookmarkGaleryItem :    hold the Bookmark to display 
 *  The Component will allow for repository Item to handle click event in the star button and send an event BookmarkNotify to GaleryComponent .
 *  The event will tell to the parent that it need to post a Bookmark for selected Repository on the server
 *  The Name of the Repository will be display with the short name until 17 characters - to get the full name , move the mouse on text and it will show the Full name
 *  in a tooltip .
 */
@Component({
  selector: 'galery-item',
  templateUrl: './galery-item.component.html',
  styleUrls: ['./galery-item.component.css']
})
export class GaleryItemComponent implements OnInit {

  @Input()
  RepositoryGaleryItem: Repository;

  @Input()
  BookmarkGaleryItem: Bookmark;

  @Output()
  BookmarkNotify: EventEmitter<Repository> = new EventEmitter<Repository>(); 

  constructor() { }

  ngOnInit() {

   
  }

  CreateBookmark() {

    this.BookmarkNotify.emit(this.RepositoryGaleryItem); 
  }
}
