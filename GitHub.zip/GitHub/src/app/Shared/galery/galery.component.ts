import { Component, OnInit, OnChanges, Input, AfterViewChecked } from '@angular/core';
import { HttpResponse } from 'selenium-webdriver/http';
import { Repository, BookmarkStatus } from '../../Models/Repository';
import { BookmarkService } from '../../Bookmarks/Services/bookmark-service';
import { Bookmark } from '../../Models/Bookmark';
import { HttpErrorResponse } from '@angular/common/http';






/*
 *  The Component represent  a control that display item like Image Galery . the Component can works with Repository models or Bookmark model .
 *  we need specify the right value in attribute GaleryType:
 *    1.Repository - display a list of repository and allow to user to bookmark repository
 *    2. Bookmark -  display a list of bookmarks retrieve from the server 
 */
@Component({
  selector: 'galery',
  templateUrl: './galery.component.html',
  styleUrls: ['./galery.component.css']
})
export class GaleryComponent implements OnInit, OnChanges {

  @Input()
  GaleryType: string = 'Repository';     // type of item display in galery 

  @Input()
  Repositories: Array<Repository>;      // list of Repositories to display 

 
  @Input()
  State: string;                       // State of the application before loading all  the items in the galery 

  Response: HttpResponse;              // response for communicatin to Bookmark Service 

  GaleryRepositories: Array<Array<Repository>>;   // Data Structure for representing all the repositories on bootstrap grid 

  GaleryBookmarks: Array<Array<Bookmark>>;        // Data Structure for representing all bookmarks on bootstrap grid 



  Bookmarks: Array<Bookmark>;                     // list of bookmark existing on the server 




/*
 *  Build the View Data Structure GaleryRepositories or GaleryBookmarks base on Galery Type 
 */
  private GetItems() {

    let count: number = 0;
    let rowID: number = 0;

    if (this.GaleryType == 'Repository') {

      this.GaleryRepositories = [];

      this.Repositories.forEach(item => {



        if (count > 5) {
          rowID++;
          count = 0;
        }

        if (count == 0) {
          let items: Array<Repository> = [];
          this.GaleryRepositories.push(items);
          this.GaleryRepositories[rowID].push(item);
          this.Bookmarks.forEach(bookmark => {
            if (item.ID == bookmark.RepositoryID)
              item.BookmarkStatus = BookmarkStatus.Active;
          });
          count++;

        }
        else if (count < 6) {
          this.GaleryRepositories[rowID].push(item);
          this.Bookmarks.forEach(bookmark => {
            if (item.ID == bookmark.RepositoryID)
              item.BookmarkStatus = BookmarkStatus.Active;
          });

          count++;
        }
      });

    }
    else {

      this.GaleryBookmarks = [];

      this.Bookmarks.forEach(item => {



        if (count > 5) {
          rowID++;
          count = 0;
        }

        if (count == 0) {
          let items: Array<Bookmark> = [];
          this.GaleryBookmarks.push(items);
          this.GaleryBookmarks[rowID].push(item);
          count++;

        }
        else if (count < 6) {
          this.GaleryBookmarks[rowID].push(item);
          count++;
        }
      });

    }

 

  

    if (this.Repositories.length == 0)
      this.State = 'Query'
    else
      this.State = "None";
  }


  constructor(private bookmarkService: BookmarkService) {

   
  }

  ngOnInit() {
    this.Bookmarks = new Array<Bookmark>();

   

    
  }


/*
 * each done on the component will check when we need to update the Data Structures GaleryRepositories or GaleryBookmarks
 *   1. Query State when we display Repositories
 *   2. display always Bookmarks
 *   3. if the Application in in state of error to do retries
 *   4. if the application already display items and we try to do another search
 *
 *  The Application will have State =Bookmarks if no bookmarks has been found in the system 
 */
  ngOnChanges() {

    if ((this.State == 'Query' && this.GaleryType == 'Repository') || this.GaleryType == 'Bookmark' || this.State == 'Error' || this.State=='None') {

      this.bookmarkService.GetBookMarks().subscribe((bookmarks: Bookmark[]) => {

        this.Bookmarks = bookmarks;


        if (this.GaleryType == 'Bookmark' && this.Bookmarks.length == 0)
          this.State = 'Bookmark';
        else {
          this.GetItems();
        }
        

      }, (error: HttpErrorResponse) => {
        console.log(error.message + " " + error.statusText);
        this.State = 'Error';

      });
    }


  }

  ngAfterViewChecked() {

    
  }



/*
 * Operation that will handle BookmarkNotify  and send it the repository that need to be bookmarked .
 * the operation will post the bookmark and set the repository in BookmarkStatus= Active ( it will display the star in yellow color )
 * If the operation will failed the repository in BookmarkStatus = Failed ( it will display the star in red color)
 */
  CreateBookmark(repository: Repository) {

    let bookmark: Bookmark = new Bookmark();

    bookmark.RepositoryID = repository.ID;
    bookmark.OwnerImageUrl = repository.Avatar;
    bookmark.RepositoryName = repository.Name;
    bookmark.CreatedDate = new Date();

    this.bookmarkService.Create(bookmark).subscribe((response: HttpResponse) => {
      this.Response = response;
      repository.BookmarkStatus = BookmarkStatus.Active;
      this.Bookmarks
    }
      , (error: string) => {
        console.log(error);
        repository.BookmarkStatus = BookmarkStatus.Failed;
      });

  }
}
