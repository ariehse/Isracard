﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace GitHubServer.Models
{
    /// <summary>
    /// define the Bookmark entity of a GITHub Repository . Hold the metadata that need to hold in the server . 
    /// </summary>
    [DataContract]
    public class Bookmark
    {
        [Required]
        [DataMember]
        public string   RepositoryID { get; set; }   // ID for a repository 

        [Required]
        [DataMember]
        public string OwnerImageUrl { get; set; }  // image url for the owner 

        [Required]
        [DataMember]
        public  string RepositoryName { get; set; }  // repository name that are bookmarked

        [DataMember]
        public   DateTime  CreatedDate { get; set; }  // date when we do bookmar operation 
    }
}