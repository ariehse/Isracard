﻿using System;
using System.Runtime.Serialization;

namespace GitHubServer.Models
{
   /// <summary>
   /// define an exception that already been found in memory on the server . the exception will hold an error code for clients, 
   /// meaning that occured business error , that we try to save the same item in the structure more than once
   /// </summary>
    public class FoundItemException : Exception
    {

        public FoundItemException()
        {
        }

        public FoundItemException(string message, int errorCode=500  ) : base(message)
        {
            this.ErrorCode = errorCode;
        }

        public int ErrorCode { get; private set; }
    }
}