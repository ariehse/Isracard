﻿using System.Collections.Generic;

namespace GitHubServer.Models
{
    /// <summary>
    /// represent a reponse that hold the list of bookmarks existing on the server 
    /// </summary>
    public class BookmarkResponse : Response 
    {
        public List<Bookmark>  Bookmarks { get; set; }
    }
}