﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GitHubServer.Models
{
    /// <summary>
    /// Represent a data structure for hold all the bookmark in memory - The data structure allow operation like add or remove a bookmard and 
    /// find existing bookmarks .
    /// If we try to add a new item  when it already exists , we will throw exception FoundItemException 
    /// 
    /// </summary>
    public class BookmarkRepository
    {
        private Dictionary<string, Bookmark> _bookmarks; 

        public BookmarkRepository()
        {
            _bookmarks = new Dictionary<string, Bookmark>(); 
        }

        /// <summary>
        /// Add a new bookmark in the structure 
        /// </summary>
        /// <param name="bookmark"></param>
        public void Add(Bookmark  bookmark )
        {


            if (!_bookmarks.Keys.Contains(bookmark.RepositoryID))
            {
                _bookmarks.Add(bookmark.RepositoryID, bookmark);
            }
            else
                throw new FoundItemException("Bookmark already exists", 1000); 
        }

        /// <summary>
        /// remove an existing bookmark 
        /// </summary>
        /// <param name="bookmark"></param>
        public void Remove (Bookmark bookmark)
        {
            Bookmark foundBookmark = _bookmarks[bookmark.RepositoryID];

            if (_bookmarks.Keys.Contains(bookmark.RepositoryID))
            {
                _bookmarks.Remove(bookmark.RepositoryID);
            }
            else
                throw new Exception("Bookmark doe not exists  exists");
        }

       
        /// <summary>
        /// Get the whole list of bookmarks existing in the structure 
        /// </summary>
        /// <returns></returns>
        public List<Bookmark>  GetBookmarks()
        {
            return _bookmarks.Values.ToList(); 
        }
    }
}