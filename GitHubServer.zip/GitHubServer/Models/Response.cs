﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GitHubServer.Models
{
    /// <summary>
    /// Represent the entity that we will return from the server to client : 
    ///    *Success: state if the request on the server succeed . 
    ///    *ErrorMessage :  message error that occured on the server in case Success=false 
    ///    *ErrorCode  :  Code that represent type of the error occured on the server
    /// </summary>
    public class Response
    {
        public bool Success { get; set; }

        public string ErrorMessage { get; set; }

        public int    ErrorCode { get; set; }
    }
}