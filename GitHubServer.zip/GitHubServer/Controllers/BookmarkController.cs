﻿using GitHubServer.Binders;
using GitHubServer.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace GitHubServer.Controllers
{
    public class BookmarkController : Controller
    {

        private object _lockObject = new object();   // Thread Synchronization Object 
    

      /// <summary>
      /// Action that will post a new Bookmark for specific GITHub Repository
      /// </summary>
      /// <param name="bookmark">the Bookmark posted </param>
      /// <returns> JSON Representation of Response Model </returns>
      [HttpPost]
      public  ActionResult  Create ( [ModelBinder(typeof (JsonModelBinder))] Bookmark bookmark  )
      {
            Response response = new Response() { Success = false, ErrorMessage = "" }; 


            if ( ModelState.IsValid )
            {
                object r1 = HttpContext.Session["Bookmarks"];
                BookmarkRepository repository = HttpContext.Cache["Bookmarks"] as BookmarkRepository;

                if (repository == null)
                {
                    repository = new BookmarkRepository();

                    lock (_lockObject)
                    {

                        HttpContext.Cache.Insert("Bookmarks", repository);
                    }


                  
                }
                try
                {
                    repository.Add(bookmark);
                    response.Success = true;
                    response.ErrorCode = 0; 

                }
                catch (FoundItemException  ex )
                {
                    response.Success = false;
                    response.ErrorMessage = "The Bookmark is already exists in the system";
                    response.ErrorCode = ex.ErrorCode;
                }
                catch(Exception ex )
                {
                    response.Success = false;
                    response.ErrorMessage = ex.Message;
                    response.ErrorCode = 500; 
                }
              
                
            }
            else
            {
                response.ErrorMessage = "Invalid Bookmark Information - can't save it in the system";
                response.ErrorCode = 400;
            }

            

            return Json(response); 
      }

        /// <summary>
        /// Action that return all existing Bookmarks save on the server 
        /// </summary>
        /// <returns>JSON Representation of a List of Bookmark Enities </returns>
        public ActionResult   GetBookmarks()
      {

            BookmarkRepository repository = HttpContext.Cache["Bookmarks"] as BookmarkRepository;
            List<Bookmark> _bookmarks = new List<Bookmark>();

            if (repository != null)
                _bookmarks = repository.GetBookmarks();
            else
            {
                lock (_lockObject)
                {
                    HttpContext.Cache.Insert("Bookmarks", new BookmarkRepository());
                }
            }

            return Json(_bookmarks,JsonRequestBehavior.AllowGet); 
      }
    }
}